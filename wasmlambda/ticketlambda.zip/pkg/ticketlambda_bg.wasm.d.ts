/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function anti_fraud(a: number, b: number, c: number, d: number, e: number, f: number): number;
export function reserve_ticket(): void;
export function greet(): void;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
export function __wbindgen_exn_store(a: number): void;

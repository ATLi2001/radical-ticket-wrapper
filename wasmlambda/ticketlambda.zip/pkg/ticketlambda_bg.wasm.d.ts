/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function anti_fraud(a: number, b: number, c: number, d: number, e: number, f: number, g: number): number;
export function __wbindgen_export_0(a: number, b: number): number;
export function __wbindgen_export_1(a: number, b: number, c: number, d: number): number;
export function __wbindgen_export_2(a: number): void;

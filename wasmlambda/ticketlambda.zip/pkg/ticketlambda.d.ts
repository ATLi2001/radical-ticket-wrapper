/* tslint:disable */
/* eslint-disable */
/**
* @param {number} _ticket_id
* @param {string} res_email
* @param {string} res_name
* @param {string} res_card
* @returns {boolean}
*/
export function anti_fraud(_ticket_id: number, res_email: string, res_name: string, res_card: string): boolean;

/* tslint:disable */
/* eslint-disable */
/**
* @param {string | undefined} [res_email]
* @param {string | undefined} [res_name]
* @param {string | undefined} [res_card]
* @returns {boolean}
*/
export function anti_fraud(res_email?: string, res_name?: string, res_card?: string): boolean;
/**
*/
export function reserve_ticket(): void;
/**
*/
export function greet(): void;

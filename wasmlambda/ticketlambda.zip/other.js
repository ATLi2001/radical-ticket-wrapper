const { anti_fraud } = require('./pkg/ticketlambda.js');
const{ performance, PerformanceObserver } = require("perf_hooks")

// console.log(pkg)
const perfObserver = new PerformanceObserver((items) => {
  items.getEntries().forEach((entry) => {
    console.log(entry)
  })
})
perfObserver.observe({ entryTypes: ["measure"], buffer: true })

console.log("Testing whether this works")

let item = {
	Version: 19,
	ID: 'ticket-0',
	Value: {
		id: 0,
		res_name: 'Test Name0',
		res_email: 'test_0@test.com',
		res_card: '0xxxx1234',
		taken: true
	},
	Key: 'ticket-0'
}

async function main() {
	performance.mark("start-inv")
	let af_result = await anti_fraud(item.Value.id, item.Value.res_email, item.Value.res_name, item.Value.res_card);
	performance.mark("end-inv")
	performance.measure("invoke-time", "start-inv", "end-inv")
	console.log(af_result)
}

main()
